/**
 * artists.js
 *
 * The app's list of Artists
 */

window.artists = [
  /* TODO */
  {
    artistID: "AID-1",
    name: "Oneheart",
    url: [
      { url: "https://www.instagram.com/oneheartisok/", name: "Instagram" },
      { url: "https://www.youtube.com/@oneheartt", name: "YouTube Channel" }
    ]
  },
  {
    artistID: "AID-2",
    name: "Antent",
    url: [
      { url: "https://www.instagram.com/antentofficial/", name: "Instagram" },
      { url: "https://www.youtube.com/@Antent", name: "YouTube Channel" }
    ]
  },
  {
    artistID: "AID-3",
    name: "lmnl",
    url: [
      { url: "https://www.instagram.com/yourpastreality/", name: "Instagram" },
      { url: "https://www.youtube.com/channel/UCeQwynIb6moziR0I2xnKwYwt", name: "YouTube Channel" }
    ]
  }
];
